// Show success message on form submit
document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("waitlistForm");
  const successMsg = document.getElementById("successMsg");

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    successMsg.style.display = "block";
    form.reset();
  });
});
